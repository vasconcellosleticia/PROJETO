/* Backend - app.js */
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const app = express();

app.use(express.json());
app.use(cors());

mongoose.connect('mongodb://127.0.0.1:27017/livrosDB', {
    useNewUrlParser: true,
    useUnifiedTopology: true
});

const AutorSchema = new mongoose.Schema({
    nome: String,
    nacionalidade: String
});

const LivroSchema = new mongoose.Schema({
    titulo: String,
    ano: Number,
    autor: { type: mongoose.Schema.Types.ObjectId, ref: 'Autor' }
});

const Autor = mongoose.model('Autor', AutorSchema);
const Livro = mongoose.model('Livro', LivroSchema);

// Rotas CRUD para Autores
app.post('/autores', async (req, res) => {
    const autor = new Autor(req.body);
    await autor.save();
    res.json(autor);
});

app.get('/autores', async (req, res) => {
    const autores = await Autor.find();
    res.json(autores);
});

app.delete('/autores/:id', async (req, res) => {
    await Autor.findByIdAndDelete(req.params.id);
    res.json({ message: 'Autor removido' });
});

// Rotas CRUD para Livros
app.post('/livros', async (req, res) => {
    const livro = new Livro(req.body);
    await livro.save();
    res.json(livro);
});

app.get('/livros', async (req, res) => {
    const livros = await Livro.find().populate('autor');
    res.json(livros);
});

app.delete('/livros/:id', async (req, res) => {
    await Livro.findByIdAndDelete(req.params.id);
    res.json({ message: 'Livro removido' });
});

app.listen(3000, () => console.log('Servidor rodando na porta 3000'));
