const API_URL = "http://localhost:3000";

// Função para carregar autores no dropdown e na lista
async function carregarAutores() {
    const response = await fetch(`${API_URL}/autores`);
    const autores = await response.json();
    
    const listaAutores = document.getElementById("listaAutores");
    const selectAutor = document.getElementById("selectAutor");

    listaAutores.innerHTML = "";
    selectAutor.innerHTML = "<option value=''>Selecione um Autor</option>";

    autores.forEach(autor => {
        const item = document.createElement("li");
        item.textContent = `${autor.nome} (${autor.nacionalidade})`;
        listaAutores.appendChild(item);

        const option = document.createElement("option");
        option.value = autor._id;
        option.textContent = autor.nome;
        selectAutor.appendChild(option);
    });
}

// Função para adicionar um autor
async function adicionarAutor() {
    const nome = document.getElementById("autorNome").value;
    const nacionalidade = document.getElementById("autorNacionalidade").value;

    await fetch(`${API_URL}/autores`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ nome, nacionalidade })
    });

    document.getElementById("autorNome").value = "";
    document.getElementById("autorNacionalidade").value = "";

    carregarAutores();
}

// Função para carregar livros
async function carregarLivros() {
    const response = await fetch(`${API_URL}/livros`);
    const livros = await response.json();
    
    const listaLivros = document.getElementById("listaLivros");
    listaLivros.innerHTML = "";

    livros.forEach(livro => {
        const item = document.createElement("li");
        item.textContent = `${livro.titulo} (${livro.ano}) - ${livro.autor.nome}`;
        listaLivros.appendChild(item);
    });
}

// Função para adicionar um livro
async function adicionarLivro() {
    const titulo = document.getElementById("livroTitulo").value;
    const ano = document.getElementById("livroAno").value;
    const autor = document.getElementById("selectAutor").value;

    if (!autor) {
        alert("Selecione um autor!");
        return;
    }

    await fetch(`${API_URL}/livros`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ titulo, ano, autor })
    });

    document.getElementById("livroTitulo").value = "";
    document.getElementById("livroAno").value = "";

    carregarLivros();
}

// Carrega os dados ao iniciar
carregarAutores();
carregarLivros();
